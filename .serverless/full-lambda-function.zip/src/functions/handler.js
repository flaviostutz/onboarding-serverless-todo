"use strict";

// src/functions/handler.ts
var usersArray = [
  {
    id: 0,
    name: "John",
    birthdate: "02-02-1990",
    city: "Amsterdam"
  },
  {
    id: 1,
    name: "Henk",
    birthdate: "02-02-1988",
    city: "Rotterdam"
  }
];
module.exports.person = async (event) => {
  return {
    statusCode: 200,
    body: JSON.stringify(
      {
        message: usersArray,
        statusCode: 200,
        input: event
      },
      null,
      2
    )
  };
};
module.exports.personId = async (event) => {
  return {
    statusCode: 200,
    body: JSON.stringify(
      {
        message: "Successfully retrieved a specific user!",
        result: usersArray[event.pathParameters.id],
        statusCode: 200,
        input: event
      },
      null,
      2
    )
  };
};
//# sourceMappingURL=handler.js.map
